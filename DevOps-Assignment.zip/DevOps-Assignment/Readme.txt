1. Answer q1 and q2 (q3 is optional) the questions.
2. Each questions directories (q1 - q3) has a problem.txt file which describes the problem and supporting files.
3. Place the answer files inside the respective questions directory itself and share the .zip file with hr@iamdave.ai
